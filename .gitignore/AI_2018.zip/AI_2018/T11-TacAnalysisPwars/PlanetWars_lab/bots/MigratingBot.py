class MigratingBot(object):

    def update(self, gameinfo):

        if gameinfo.my_planets and gameinfo.not_my_planets:

            #My planet with the most ships
            src = max(gameinfo.my_planets.values(), key=lambda p: p.num_ships)


            #Search for the minimum distance planet in the not_my_planet_list. That is the destination. 
            dest = min(gameinfo.not_my_planets.values(), key=lambda p: p.distance_to(src))

            #decider of which "dest" to use
            if src.num_ships > 10:
                gameinfo.planet_order(src, dest, int(src.num_ships * 0.75) )
