from vector2d import Vector2D
from vector2d import Point2D
from graphics import egi, KEY
from math import sin, cos, radians, degrees, asin
from random import random, randrange, uniform
from path import Path


BULLET_MODES = {
    KEY._1: 'Rifle',
    KEY._2: 'Rocket',
    KEY._3: 'Handgun',
    KEY._4: 'Grenade',
    KEY._5: 'Regular'

}

class Bullet(object):


    def __init__(self, target=None, marksman=None, mode = 'Regular'):

        self.tarmax = target.max_speed

        self.tarpos = Vector2D(target.pos.x, target.pos.y)
        self.tarvel = Vector2D(target.vel.x, target.vel.y)
        self.marvel = Vector2D(marksman.pos.x, marksman.pos.y)
        self.marpos = Vector2D(marksman.pos.x, marksman.pos.y)
        self.pos = Vector2D(marksman.pos.x, marksman.pos.y)

        self.relpos = (self.tarpos - self.pos).normalise()
        self.relvel = (self.tarvel - self.marvel). normalise()

        self.mode = mode
        self.speed = 400

        self.eta = Vector2D.distance(self.marpos, self.tarpos) / (self.speed)

        self.predict = self.tarpos + (self.tarvel * self.eta)

        self.dir = (self.predict - self.marpos).normalise()









    def update(self,delta):
        ''' update vehicle position and orientation '''

        self.pos += self.dir * self.speed * delta





    def render(self,delta):
        egi.green_pen()
        egi.circle(self.pos, 3, True)

        egi.cross(self.predict, 5)



