from random import randrange

class SmartBot(object):

    def update(self, gameinfo):

        if gameinfo.my_planets and gameinfo.not_my_planets:



            #Defence modes
            #If planet is in battle, and number of ships is really low, send forces to closest ally planet
            #If recently attacked, defend it with strongest fleeted planet
            for planet in gameinfo.my_planets.values():

                if planet.is_battle == True:
                    if planet.num_ships < 40 and planet.num_ships >= 21:
                        print("SMARTBOT:: ", planet.id, "IS UNDER ATTACK, DEFEND")
                        src = max(gameinfo.my_planets.values(), key=lambda p: p.num_ships)
                        dest = planet
                        gameinfo.planet_order(src, dest, int(src.num_ships * .5))
                    if planet.num_ships <= 20:
                        print("SMARTBOT:: ", planet.id, "IS UNDER ATTACK, KAMIKAZE")
                        src = planet
                        dest = min(gameinfo.not_my_planets.values(), key=lambda p: p.distance_to(src))
                        gameinfo.planet_order(src, dest, int(src.num_ships * 1))


            #SCOUT MODE: Will send a large army at the start, and at random periods of time throughout game
            if len(gameinfo.my_planets) < 2:
                src = max(gameinfo.my_planets.values(), key=lambda p: p.num_ships)
                if(src.num_ships > 30):

                    dest = max(gameinfo.not_my_planets.values(), key=lambda p: p.distance_to(src))

                    gameinfo.planet_order(src, dest, int(src.num_ships * 0.95))
                    print("SMARTBOT:: DISTRACT ", dest.id)




            chance = randrange(0,100)

            if chance > 98:
                src = max(gameinfo.my_planets.values(), key=lambda p: p.num_ships)
                dest = max(gameinfo.not_my_planets.values(), key=lambda p: p.distance_to(src))

                gameinfo.planet_order(src, dest, int(src.num_ships * 0.75))
                print("SMARTBOT:: INFILTRATION ", dest.id)




            # My planet with the most ships
            src = max(gameinfo.my_planets.values(), key=lambda p: p.num_ships)

            if chance <= 97 and chance >= 90:
                # Search for the lowest populated enemy or neutral planet and attempt to grab it
                dest = min(gameinfo.not_my_planets.values(), key=lambda p: p.num_ships)
                gameinfo.planet_order(src, dest, int(src.num_ships * 0.99))
                print('SMARTBOT:: Heavy Hitting Planet ', dest.id)

            else:

                #Search for the minimum distance planet in the not_my_planet_list. That is the destination.
                dest = min(gameinfo.not_my_planets.values(), key=lambda p: p.distance_to(src))

                #decider of which "dest" to use
                #If my src planet has more than 5 ships, send 75% from src to dest
                if src.num_ships > 10:
                    gameinfo.planet_order(src, dest, int(src.num_ships * 0.75) )


            #If all else fails, then attempt to grab highest growth rate
            if src.num_ships > 70:
                print('SMARTBOT:: Attempting to gain Highest Growth rate planet ', dest.id)
                dest = max(gameinfo.not_my_planets.values(), key=lambda p: p.growth_rate)
                gameinfo.planet_order(src, dest, int(src.num_ships * 0.9))


